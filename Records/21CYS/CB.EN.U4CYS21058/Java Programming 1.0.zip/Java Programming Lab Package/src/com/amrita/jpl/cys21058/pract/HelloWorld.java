package com.amrita.jpl.cys21058.pract;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}

//author Siddharth Krishna R
//@version 0.1