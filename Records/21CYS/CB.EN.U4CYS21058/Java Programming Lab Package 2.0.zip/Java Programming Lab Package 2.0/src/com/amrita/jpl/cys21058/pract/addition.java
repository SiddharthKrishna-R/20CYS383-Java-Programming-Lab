package com.amrita.jpl.cys21058.pract;
public class addition {
    public static void main(String[] args) {
        int a=9;
        int b=13;
        int c=a+b;
        System.out.println(c);
    }
}

//author Siddharth Krishna R
//@version 0.1